<meta property="og:url" content="https://project.nubisub.xyz/" />
<meta property="og:type" content="website" />
<meta property="og:image" content="https://project.nubisub.xyz/images/socialcard.jpg" />

<meta name="twitter:card" content="summary_large_image" />
<!--<meta property="twitter:domain" content="project.nubisub.xyz" />-->
<meta property="twitter:url" content="https://project.nubisub.xyz/" />
<meta name="twitter:image" content="https://project.nubisub.xyz/images/socialcard.jpg" />