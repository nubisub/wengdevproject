<?php
// session
session_start();
// destroy
session_unset();
session_destroy();
header('Location: index.php');
// unset all
?>