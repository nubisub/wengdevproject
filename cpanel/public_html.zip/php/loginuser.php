<?php
    require 'create/connect.php';
    isset($_POST['username']) ? $username = $_POST['username'] : $username = '';
    isset($_POST['password']) ? $password = $_POST['password'] : $password = '';

    // if username and password
        $sql = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $count = $stmt->rowCount();
        if ($count > 0) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            $_COOKIE['username'] = $username;
            // make cookie password md5
            $_COOKIE['password'] = md5($password);
            header("Location: index.php");
        } else {
            // not in database
            // header("Location: index.php");
            // redirect to index an alert
            $_SESSION['usernametemplogin'] = $username;
            $_SESSION['passwordtemplogin'] = $password;
            $_SESSION['timeregisterlogin'] = time();
            header("Location: index.php");
        }
        
?>